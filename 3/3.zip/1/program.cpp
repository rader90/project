#include "program.h"

using _geek::print_a;

int main(int argc, char** args)
{
	int a=1;
	print_a(a);
	return 0;
}