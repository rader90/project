#include <iostream>
void printVal(int a);
int VarDel(int a, int b);
