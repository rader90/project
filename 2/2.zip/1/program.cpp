#include <iostream>

using namespace std;

int main (int argc, char** args)
{
	short a;
	unsigned char b;
	a=45000;
	b='1400';
	//cout << a;
	//cout << b;
	cout << "a="<< a <<"\nb="<<b << endl; 
	return 0;	
}
